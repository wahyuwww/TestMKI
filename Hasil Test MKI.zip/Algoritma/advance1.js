// Graph dengan node:
// A - C - F - H - L - N
// 6-5-3-2-5 = 21 node yang ditempuh selama A sampai N